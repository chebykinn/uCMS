<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">	
<title><?php $ucms->cout("ucms.page_not_found.title"); ?></title>
</head>
<body>
<h1><?php $ucms->cout("ucms.page_not_found.message"); ?></h1>
</body>
</html>