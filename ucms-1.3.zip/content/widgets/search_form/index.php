<?php
$ucms->template(get_module("path", "search").'forms/search-form-min.php');
?>