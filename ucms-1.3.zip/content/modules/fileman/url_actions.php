<?php
add_url_action("download", get_module("path", "fileman"), 'download.php', true);
?>