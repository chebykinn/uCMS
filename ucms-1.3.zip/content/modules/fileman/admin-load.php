<?php
add_sidebar_item("module.fileman.sidebar.label", "fileman", "fileman", 1, true, 12);
?>