<?php
$module_accessID = "fileman";
$module_accessLVL = 1;
$title = "module.fileman.title";
$manage_file = "fileman-adm.php";
?>