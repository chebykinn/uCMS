<?php
$module_accessID = "themes";
$module_accessLVL = 1;
$title = "module.themes.title";
$manage_file = "themes-adm.php";
?>