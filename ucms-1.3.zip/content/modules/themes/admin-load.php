<?php
add_sidebar_item($ucms->cout("module.themes.sidebar.label", true), "themes", "themes", 1, true, 8);
?>