<?php
add_sidebar_item("module.users.sidebar.label", "users", "users", 2, true, 5);
add_sidebar_item("module.users.sidebar.groups.label", "users", "users", 7, false, 6, "&amp;section=groups");
add_settings_item("module.users.sidebar.settings.label", "users", "users", 7, 4);
?>