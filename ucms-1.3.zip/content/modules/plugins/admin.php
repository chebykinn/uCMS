<?php
$module_accessID = "plugins";
$module_accessLVL = 1;
$title = "module.plugins.title";
$manage_file = "plugins-adm.php";
?>