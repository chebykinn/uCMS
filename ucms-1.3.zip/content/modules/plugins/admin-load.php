<?php
add_sidebar_item($ucms->cout("module.plugins.sidebar.label", true), "plugins", "plugins", 1, false, 10);
?>