<?php
$module_accessID = "widgets";
$module_accessLVL = 1;
$title = "module.widgets.title";
$manage_file = "widgets-adm.php";
?>