<?php
require ABSPATH.WIDGETS_MODULE_PATH.'widgets.php';
$widget = new uWidgets(); //Запуск виджетов
?>