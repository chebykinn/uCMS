<?php
add_sidebar_item($ucms->cout("module.widgets.sidebar.label", true), "widgets", "widgets", 1, false, 9);
?>