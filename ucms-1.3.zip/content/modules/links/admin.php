<?php
$module_accessID = "links";
$module_accessLVL = 1;
$title = "module.links.title";
$manage_file = "links-adm.php";
?>