<?php
add_sidebar_item($ucms->cout("module.links.sidebar.label", true), "links", "links", 1, true, 7);
?>