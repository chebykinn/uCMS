<?php
$module_accessID = "comments";
$module_accessLVL = 2;
$title = "module.comments.title";
$manage_file = "comments-adm.php";
?>