<?php
add_url_action('new-comment', COMMENTS_MODULE_PATH, "new-comment.php");
?>