<?php
add_sidebar_item("module.comments.sidebar.label", "comments", "comments", 2, false, 3);
add_settings_item("module.comments.sidebar.settings.label", "comments", "comments", 7, 2);
?>