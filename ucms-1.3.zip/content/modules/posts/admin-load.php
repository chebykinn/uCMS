<?php
add_sidebar_item("module.posts.sidebar.label", "posts", "posts", 2, true, 1);
add_sidebar_item("module.posts.sidebar.categories.label", "posts", "posts", 4, "", 2, "&amp;section=categories");
add_settings_item("module.posts.sidebar.settings.label", "posts", "posts", 7, 1);
?>