<?php
$module_accessID = "pages";
$module_accessLVL = 2;
$title = "module.pages.title";
$manage_file = "pages-adm.php";
?>