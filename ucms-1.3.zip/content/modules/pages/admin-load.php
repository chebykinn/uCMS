<?php
add_sidebar_item("module.pages.sidebar.label", "pages", "pages", 2, true, 4);
add_settings_item("module.pages.sidebar.settings.label", "pages", "pages", 7, 3);
?>