<?php
add_url_action(PAGE_SEF_PREFIX, PAGES_MODULE_PATH, 'pages-load.php');
?>