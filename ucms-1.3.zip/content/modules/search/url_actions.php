<?php
add_url_action("search", MODULES_PATH.'search/');
?>