<?php
add_settings_item("module.search.sidebar.settings.label", "search", "system", 7, 5);
?>