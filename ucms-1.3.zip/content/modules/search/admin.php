<?php
$module_accessID = "system";
$module_accessLVL = 1;
$title = "module.search.title";
?>