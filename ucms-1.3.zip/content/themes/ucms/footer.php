</tr>
</table>
</div>
<div id="footer">IVaN4B's μCMS Copyright 2011-<?php echo date("Y"); ?><span><?php echo $ucms->cout("theme.ucms.footer.queries_count", true).$udb->get_queries_count().". "; ?><?php //id="info"
echo $ucms->cout("theme.ucms.footer.loadtime", true, $ucms->get_load_time());
?></span></div>
<div id="footer-bottom">
</div>
</body>
</html>