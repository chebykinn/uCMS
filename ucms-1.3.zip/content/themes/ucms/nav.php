<div id="menu">
	<div class="menu">
	<?php $widget->load("menu_links"); ?>
	</div>
<div id="search" style="float:right; padding:10px;">
	<?php $widget->load("search_form"); ?>
</div>
</div>
<table id="main">
<tr>
<td id="content-cell">