μCMS - simple and fast yet functional content management system
====
μCMS is my home project of creating simple but functional CMS which can serve as an useful tool for freelancers, who creating sites.
However μCMS can be used by regular users, because it's easy to install and use it like WordPress and any other CMS.