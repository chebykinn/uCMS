<?php
/**
* uWidgets fallback class
*
* @package uCMS
* @since 1.3
* @version 1.3
*
*/
class widgets_min{
	function load(){
		return false;
	}
}
?>